(function(){const A=new Set(["a","button","input","textarea","select"]),v=new Set(["button","link","textbox","combobox","listbox","menuitem","menuitemcheckbox","menuitemradio","option","radio","checkbox","switch","tab","searchbox"]),S=150;function k(t){const e=window.getComputedStyle(t);if(e.display==="none"||e.visibility==="hidden"||parseFloat(e.opacity)===0)return!1;const r=t.getBoundingClientRect();return r.width>0&&r.height>0}function b(t){const e=t.getBoundingClientRect();return e.top>=0&&e.bottom<=window.innerHeight&&e.left>=0&&e.right<=window.innerWidth}function T(t){const e=t.tagName.toLowerCase();if(A.has(e)||t.hasAttribute("onclick")||t.getAttribute("contenteditable")==="true")return!0;const r=t.getAttribute("role");return!!(r&&v.has(r))}function h(t,e=60){if(!t)return"";const r=t.replace(/\s+/g," ").trim();return r.length>e?r.slice(0,e)+"...":r}function g(){const e=Array.from(document.querySelectorAll('a, button, input, textarea, select, [role], [onclick], [contenteditable="true"]')).filter(n=>k(n)&&T(n));return e.sort((n,o)=>{const i=b(n)?0:1,c=b(o)?0:1;return i-c}),e.slice(0,S).map((n,o)=>({id:`el_${o}`,tag:n.tagName.toLowerCase(),text:h(n.textContent)||h(n.value),type:n.getAttribute("type")||null,placeholder:n.getAttribute("placeholder")||null,ariaLabel:n.getAttribute("aria-label")||null,inViewport:b(n)}))}const f="data-agent-id";function m(t){document.querySelectorAll(`[${f}]`).forEach(e=>{e.removeAttribute(f)}),t.forEach(e=>{const r=Array.from(document.querySelectorAll(e.tag));let n=null;e.text&&(n=r.find(o=>(o.textContent||"").replace(/\s+/g," ").trim().startsWith(e.text))||null),!n&&e.placeholder&&(n=r.find(o=>o.getAttribute("placeholder")===e.placeholder)||null),!n&&e.ariaLabel&&(n=r.find(o=>o.getAttribute("aria-label")===e.ariaLabel)||null),n&&n.setAttribute(f,e.id)})}function y(t){return document.querySelector(`[${f}="el_${t}"]`)}function _(t){return window.location.href=t,{success:!0,newUrl:t}}function w(t){const e=y(t);return e?e.ownerDocument!==document?{success:!1,error:`Element el_${t} is inside an iframe — not supported`}:(e.scrollIntoView({behavior:"instant",block:"center"}),e.click(),e.dispatchEvent(new MouseEvent("click",{bubbles:!0,cancelable:!0})),e.tagName==="A"&&e.href?{success:!0}:e.type==="submit"?{success:!0}:{success:!0}):{success:!1,error:`Element el_${t} not found`}}function C(t,e){var u,s;const r=y(t);if(!r)return{success:!1,error:`Element el_${t} not found`};r.scrollIntoView({behavior:"instant",block:"center"});const n=r.tagName.toLowerCase();if(n==="select"){const a=r,d=Array.from(a.options).find(p=>p.text.toLowerCase().includes(e.toLowerCase())||p.value===e);return d?(a.value=d.value,a.dispatchEvent(new Event("change",{bubbles:!0})),a.dispatchEvent(new Event("input",{bubbles:!0})),{success:!0}):{success:!1,error:`Option "${e}" not found in select`}}if(r.getAttribute("contenteditable")==="true"||r.getAttribute("role")==="textbox")return r.textContent=e,r.dispatchEvent(new Event("input",{bubbles:!0})),r.dispatchEvent(new Event("change",{bubbles:!0})),{success:!0};const o=r;r.focus();const i=(u=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:u.set,c=(s=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value"))==null?void 0:s.set;return n==="input"&&i?i.call(o,e):n==="textarea"&&c?c.call(o,e):o.value=e,o.dispatchEvent(new Event("input",{bubbles:!0})),o.dispatchEvent(new Event("change",{bubbles:!0})),o.dispatchEvent(new KeyboardEvent("keydown",{bubbles:!0})),o.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0})),{success:!0}}function L(t){const e=t==="down"?300:-300;return window.scrollBy({top:e,behavior:"smooth"}),{success:!0}}function M(t){try{const e=document.querySelectorAll(t);return{success:!0,data:Array.from(e).map(n=>{var o;return((o=n.textContent)==null?void 0:o.trim())||""})}}catch{return{success:!1,data:[],error:`Invalid selector: ${t}`}}}function I(t){const e=Math.min(t,1e4);return new Promise(r=>{setTimeout(()=>r({success:!0}),e)})}const N=500,G=8e3;function O(){return new Promise(t=>{const e=Date.now(),r=()=>{document.readyState==="complete"&&(D()||Date.now()-e>G)?setTimeout(t,N):setTimeout(r,200)};r()})}function D(){return!performance.getEntriesByType("resource").some(r=>r.transferSize===0&&r.duration===0&&!r.responseEnd)}const q="LOGEXUS:OBSERVE",U="LOGEXUS:EXECUTE",P="LOGEXUS:PING",V="LOGEXUS:PONG",X="LOGEXUS:MANAGED";let E=!1;const $=['iframe[src*="recaptcha"]','iframe[src*="hcaptcha"]',"div.g-recaptcha","div.h-captcha",'[class*="captcha"]','[id*="captcha"]','img[src*="captcha"]'];let x=!1;function B(){for(const t of $)try{if(document.querySelector(t))return!0}catch{}return!1}function F(){if(E)return;E=!0;const t=document.createElement("div");t.id="logexus-badge",t.innerHTML=`
    <style>
      #logexus-badge {
        all: initial;
        position: fixed;
        bottom: 12px;
        right: 12px;
        z-index: 2147483647;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 6px 14px;
        background: rgba(0,0,0,0.82);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 20px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 12px;
        font-weight: 500;
        color: #fff;
        letter-spacing: 0.3px;
        cursor: default;
        user-select: none;
        -webkit-user-select: none;
        transition: opacity 0.3s;
        box-shadow: 0 4px 16px rgba(0,0,0,0.3);
      }
      #logexus-badge .lx-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #10b981;
        box-shadow: 0 0 6px #10b981;
        flex-shrink: 0;
      }
      #logexus-badge .lx-text {
        white-space: nowrap;
      }
      #logexus-badge .lx-divider {
        width: 1px;
        height: 12px;
        background: rgba(255,255,255,0.2);
        flex-shrink: 0;
      }
      #logexus-badge:hover {
        opacity: 0.7;
      }
    </style>
    <span class="lx-dot"></span>
    <span class="lx-text">My Logexus Browser</span>
  `,document.body.appendChild(t)}chrome.runtime.onMessage.addListener((t,e,r)=>{if(t.type===X)return F(),!1;if(t.type===P)return B()&&!x&&(x=!0,chrome.runtime.sendMessage({type:"LOGEXUS:CAPTCHA_DETECTED",payload:{}}).catch(()=>{})),r({type:V}),!0;if(t.type===q){try{const n=g();m(n),r({url:window.location.href,title:document.title,elements:n})}catch(n){r({error:n instanceof Error?n.message:String(n),url:window.location.href,elements:[]})}return!0}return t.type===U?((async()=>{try{const{action:n,targetId:o,value:i}=t;let c;switch(n){case"navigate":r({success:!0,url:i}),requestAnimationFrame(()=>{requestAnimationFrame(()=>{_(i)})});return;case"click":{const s=Number(String(o).replace("el_","")),a=document.querySelector(`[data-agent-id="el_${s}"]`);if(a&&(a.tagName==="A"||a.type==="submit")){const l=a.href;r({success:!0,url:l||window.location.href});const d=l&&l!==window.location.href?l:null;requestAnimationFrame(d?()=>{requestAnimationFrame(()=>{window.location.href=d})}:()=>w(s));return}c=w(s);break}case"type":c=C(Number(String(o).replace("el_","")),i);break;case"scroll":c=L(i);break;case"extract":c=M(i);break;case"wait":c=await I(Number(i)||1e3);break;default:c={success:!1,error:`Unknown action: ${n}`}}c.success&&n!=="wait"&&n!=="navigate"&&await O();const u=g();m(u),r({success:c.success,error:c.error,url:window.location.href,title:document.title,elements:u,data:c.data})}catch(n){r({error:n instanceof Error?n.message:String(n),url:window.location.href,elements:[]})}})(),!0):!1});
})()
